export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
